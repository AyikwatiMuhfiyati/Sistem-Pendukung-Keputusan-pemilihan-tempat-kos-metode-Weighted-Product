# spk-weight-product
Sistem Pendukung Keputusan metode Weight Product Berbasis Web
* Menggunakan PHP dan MYSQLI
* Open Source, silahkan di buat bahan pembelajaran
* jangan di jual yah
* jika bermanfaat, minta klik tombol star nya, terima kasih :)
